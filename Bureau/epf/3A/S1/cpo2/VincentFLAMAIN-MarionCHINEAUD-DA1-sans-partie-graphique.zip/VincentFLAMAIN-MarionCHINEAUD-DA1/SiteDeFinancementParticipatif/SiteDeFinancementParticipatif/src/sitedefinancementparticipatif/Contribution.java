/*
financement participatif 
Marion Chineaud & Vincent Flamain 
06/02/21
 */
package sitedefinancementparticipatif;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;

/**
 *
 * @author vincent
 */
public class Contribution {

    private Investisseur investisseur;
    private Projet projetSoutenu;
    private int sommeInvestie;

    public Contribution(Projet projetSoutenu, int sommeInvestie) {
        this.projetSoutenu = projetSoutenu;
        this.sommeInvestie = sommeInvestie;
    }

    @Override
    public String toString() {
        return "Contribution{ projetSoutenu=" + projetSoutenu.getId() + ", sommeInvestie=" + sommeInvestie + '}';
    }

    public int getSommeInvestie() {
        return sommeInvestie;
    }

    public void sauvegarde(String nomFichier) {
        try {
            FileWriter fich = new FileWriter(nomFichier, true); 
            fich.write(sommeInvestie + System.lineSeparator());
            fich.write(projetSoutenu.getId() + System.lineSeparator());
            fich.close();
        } catch (IOException ex) {
            System.out.println("erreur dans la sauvgarde ");

        }
    }
}
