/*
financement participatif 
Marion Chineaud & Vincent Flamain 
06/02/21
 */
package sitedefinancementparticipatif;

import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author vincent
 */
public class Utilisateur {
    
    protected String nom;
    protected String mail;
    protected String mdp;

    public Utilisateur(String nom, String mail, String mdp) {
        this.nom = nom;
        this.mail = mail;
        this.mdp = mdp;
    }

    @Override
    public String toString() {
        return "Utilisateur{" + "nom=" + nom + ", mail=" + mail + ", mdp=" + mdp + '}';
    }

    public boolean testMdp(String mdpCherche){ // verifier le mdp 
        boolean trouve = false;
        if(mdp.equals(mdpCherche)){
            trouve = true;
        }
        return trouve;
    }
    
        public String getmail () {
        return mail;
    }
        
         public void sauvegarde(String nomFichier) { 
        try {
            FileWriter fich = new FileWriter(nomFichier, true );
            fich.write( "\n");
            fich.write(nom + System.lineSeparator());
            fich.write(mail + System.lineSeparator());
            fich.write(mdp + System.lineSeparator() + System.lineSeparator() );
            fich.close();
        } catch (IOException ex) {
            System.out.println("erreur dans la sauvgarde ");
        }

    }
    
    
}