/*
financement participatif 
Marion Chineaud & Vincent Flamain 
06/02/21
 */
package sitedefinancementparticipatif;

import java.time.LocalDate;
import java.util.LinkedList;
import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Scanner;

/**
 *
 * @author vincent
 */
public class SiteDeFinancementParticipatif {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {

//        Utilisateur Uti = new Utilisateur("marion", "@", "marionLeCrouton");
//        boolean test = Uti.testMdp("marionLeCrouton");
//        System.out.println(test);
//        LinkedList projetPropose = new LinkedList();
//        LinkedList projetPropose2 = new LinkedList();
//        Createur c2 = new Createur("Leo", "@l", "boubou");
//        Projet p1 = c.newProjet("v", "w", "x", "y", "z", LocalDate.now(), 107, 22);
//        Projet p2 = c2.newProjet("1", "2", "3", "4", "5", LocalDate.now(), 3687, 30);
//        Projet p3 = c2.newProjet("6", "7", "8", "9", "0", LocalDate.now(), 2407, 282);
//        c.voirInfosP(p);
//        projetPropose.add(p);
//        projetPropose.add(p1);
//        projetPropose.add(p2);
//        projetPropose.add(p3);
//        c.prolongationDate(p);
//        System.out.println(p.getDateLancement());
//        LinkedList investissements = new LinkedList();
//        investissements.add(p);
//        investissements.add(p1);
//        Investisseur i = new Investisseur(investissements, "marion", "@", "marionLeCrouton");
//        LinkedList investissements = new LinkedList();
//        Contribution contri = new Contribution(p1, 200);
//        LinkedList investissements2 = new LinkedList();
//        i.soutienP(p, contri);
//        investissements.add(contri);c
//         
//        'est le but de soutientP() donc inutile
//        Investisseur i2 = new Investisseur("thisma", "@m", "le s");
//        Contribution contri2 = new Contribution(p2, 341);
//
//        i2.soutienP(p, contri2);
//
//        i.BilanInvest();
//        Recommandation recom = new Recommandation("pas mal mais peut mieux faire", i);
//
//        p1.donnerRecom(recom);
//        p1.soutienProjet(contri);
//        listInvestisseur.add(i);
//        listInvestisseur.add(i2);
//
//        listCreateur.add(c);
//        listCreateur.add(c2);
//           ---------- site ---------------
        Createur c = new Createur("Vincent", "@", "ici");
        Projet p = c.newProjet("Construire un puit ", "investit", "innovation", "action dans le projet", "A00", LocalDate.now(), 10467, 122);
        Investisseur i = new Investisseur("marion", "@", "LPB");
        LinkedList listInvestisseur = new LinkedList();
        //listInvestisseur.add(i);
        LinkedList listCreateur = new LinkedList();
        //listCreateur.add(c);
        LinkedList projetPropose = new LinkedList();
        //projetPropose.add(p);

        Site s = new Site(projetPropose, listCreateur, listInvestisseur);

        s.chargement();
        
        System.out.println(s.getListC());
        System.out.println(s.getlistI());
        System.out.println(s.getlistP());
;
        // A ne pas suprimer debut du menue principal 
        Scanner sc = new Scanner(System.in);
        sc = new Scanner(System.in);
        int type = 0;
        int action = 0;
        int utilisateur = 0;
        String idP = "";
        String idI = "";
        String idC = "";
        String mail = "";
        boolean menu = true;
        System.out.println(" Bienvenue sur notre site de financement participatif  ");
        boolean identification = true;
        while (identification) {
            boolean entier = false;
            while (!entier) {
                try {
                    entier = true;
                    System.out.println(" Inscription taper (1)");
                    System.out.println(" Connection taper (2)");
                    type = sc.nextInt();
                } catch (InputMismatchException ex) {
                    System.out.println(" Vous vous etes trompé ");
                    sc = new Scanner(System.in);
                    entier = false;
                }
            }
            switch (type) {
                case 1:
                    System.out.println(" quel est votre mail ?");
                    sc = new Scanner(System.in);
                    mail = sc.nextLine();
                    utilisateur = s.Inscription(mail);
                    identification = false;
                    break;
                case 2:
                    System.out.println(" quel est votre mail ?");
                    sc = new Scanner(System.in);
                    mail = sc.nextLine();
                    utilisateur = s.Connexion(mail);
                    identification = false;
                    break;
                default:
                    System.out.println(" Vous vous etes trompé");
            }
        }

        switch (utilisateur) {

            case 1: // cas createur
                while (menu) {
                    System.out.println("***************** Menus createur *****************\n  \n");
                    System.out.println(" Que voulez vous faire ? ");
                    System.out.println(" Pour créer un nouveau projet taper (1) ");
                    System.out.println(" Pour voir l'avancement d'un projet taper (2) ");
                    System.out.println(" Pour modifier la date du lancement taper (3) ");
                    System.out.println(" Pour rechercher des information sur un investisseur  taper (4) ");
                    System.out.println(" Pour annuler un projet taper (5) ");
                    System.out.println(" Pour clore une collecte taper (6) ");
                    System.out.println(" Pour quitter le site et sauvegarder taper (7) ");
                    action = sc.nextInt();
                    //Createur crea = s.RechercheC(mail);
                    switch (action) { // traiter le probleme des lettre avec un while try catch 

                        case 1:
                            s.proposeProjet(); 
                            break;
                        case 2:
                            System.out.println(" Rentrez l'identifiant du projet que vous voulez voir ");
                            sc = new Scanner(System.in);
                            idP = sc.nextLine();
                            Projet proj3 = s.RecherchePcreateur(idP);
                            s.VoirInfosProjet(proj3);
                            break;
                        case 3:
                            System.out.println(" Rentrez l'identifiant du projet que vous voulez modifier ");
                            sc = new Scanner(System.in);
                            idP = sc.nextLine();
                            Projet proj1 = s.RecherchePcreateur(idP);
                            s.prolongeDate(proj1);
                            break;
                        case 4:
                            System.out.println(" Rentrez le mail de l'investiseur que vous recherchez ");
                            sc = new Scanner(System.in);
                            idI = sc.nextLine();
                            Investisseur inv = s.RechercheI(idI);
                            s.VoirInfosInvestisseur(inv);
                            break;
                        case 5:
                             
                            System.out.println(" Rentrez l'identifiant du projet que vous voulez annuler ");
                            sc = new Scanner(System.in);
                            idP = sc.nextLine();
                            Projet proj2 = s.RecherchePcreateur(idP); 
                            s.projetAnnule(proj2);
                            break;
                        case 6:
                            System.out.println(" Rentrez l'identifiant du projet que vous voulez clore ");
                            sc = new Scanner(System.in);
                            idP = sc.nextLine();
                            Projet proj4 = s.RecherchePcreateur(idP);
                            s.cloreCollect(proj4);
                            break;
                        case 7:
                            s.Sauvegarde();
                            menu = false;
                            break;
                        default:
                            System.out.println(" Le chiffre que vous avez tapé n'est pas dans la liste");

                            break;
                    }

                }

            case 2: // cas investisseur 
                while (menu) {
                    System.out.println("***************** Menus investisseur *****************\n \n \n");
                    System.out.println(" Que voulez vous faire ? ");
                    System.out.println(" Pour rechercher un nouveau projet taper (1) ");
                    System.out.println(" Pour investir dans un nouveau projet taper (2) ");
                    System.out.println(" Pour voir l'avancement d'un projet taper (3) ");
                    System.out.println(" Pour voir des informations sur un createur taper (4) ");
                    System.out.println(" Pour donner des recommandations taper (5) ");
                    System.out.println(" Pour obtenir un bilan sur investissements taper (6) ");
                    System.out.println(" Pour quitter le site et sauvgarder taper (7) ");
                    action = sc.nextInt();
                    switch (action) { // traiter le probleme des lettre avec un while try catch 
                        case 1:
                            s.RecherchePCritere();
                            break;
                        case 2: 
                            System.out.println(" Rentrez l'identifiant du projet dans lequel vous voulez investir");
                            sc = new Scanner(System.in);
                            idP = sc.nextLine();
                            System.out.println(" Quelle somme voulez vous investir  ");
                            sc = new Scanner(System.in);
                            int sommeInvest = sc.nextInt();
                            Projet proj2 = s.RechercheP(idP);
                            s.soutientProjet(proj2, sommeInvest);
                            break;
                        case 3:
                            System.out.println(" Rentrez l'identifiant du projet dont vous vous voulez voir l'avancement ");
                            sc = new Scanner(System.in);
                            idP = sc.nextLine();
                            Projet proj4 = s.RechercheP(idP);
                            s.VoirInfosProjet(proj4);
                            if (proj4.getProjetAnnule() == true) {
                                System.out.println("Le projet que vous tentez de rechercher n'est plus d'actualité");
                            }
                            if (proj4.getrecolteOuverte() == false) {
                                System.out.println("La recollte du projet dans lequel vous tentez d'investir n'est plus d'actualité");
                            }
                            break;
                        case 4: 
                            System.out.println(" Rentrez le mail du createur que vous voulez voir ");
                            sc = new Scanner(System.in);
                            idC = sc.nextLine();
                            c = s.RechercheC(idC);
                            s.VoirInfosCreateur(c);
                            break;
                        case 5:
                            System.out.println(" Rentrez l'id du projet pour lequel vous voulez donner une recommandation  ");
                            sc = new Scanner(System.in);
                            idC = sc.nextLine();
                            Projet proj3 = s.RechercheP(idC);
                            System.out.println(" vous pouvez entrer votre recommandation  ");
                            sc = new Scanner(System.in);
                            String Recom = sc.nextLine();
                            s.donnerRecommandation(proj3, Recom);
                            break;
                        case 6:
                            s.BilanIvestissement(); ;
                            break;
                        case 7:
                            s.Sauvegarde();
                            menu = false;
                            break;
                        default:
                            System.out.println(" Le chiffre que vous avez tapé n'est pas dans la liste");
                    }
                }
            default:
        }
    }

}
