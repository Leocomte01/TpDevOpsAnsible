/*
finacement participatif 
Marion Chineaud & Vincent Flamain 
06/02/21
 */
package sitedefinancementparticipatif;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

/**
 *
 * @author vincent
 */
public class Site {

    private LinkedList listProjets;
    private LinkedList listC;
    private LinkedList listI;
    private int nbrProjet;
    private Utilisateur utilisateurConnecte;
    private final String nomDossier = "src\\Sauvegardes\\";

    public Site(LinkedList listProjets, LinkedList listC, LinkedList listI) {
        this.listProjets = listProjets;
        this.listC = listC;
        this.listI = listI;
    }

    @Override
    public String toString() {
        return "Site{" + "listProjets=" + listProjets + ", listC=" + listC + ", listI=" + listI
                            + ", utilisateurConnecte=" + utilisateurConnecte + '}';
    }

    public LinkedList getListC() {
        return listC;
    }

    public int getnbrProjet() {
        return nbrProjet;
    }

    public LinkedList getlistI() {
        return listI;
    }

    public LinkedList getlistC() {
        return listC;
    }

    public LinkedList getlistP() {
        return listProjets;
    }

    public int Connexion(String mail) { // méthode initial 
        boolean stop = false;
        Scanner sc = new Scanner(System.in);
        while (!stop) {
            System.out.println("créateur (1) investisseur (2) ");
            int type = sc.nextInt();
            stop = true;
            Createur c = null;
            Investisseur i = null;
            sc = new Scanner(System.in);
            switch (type) {
                case 1:// createur 
                    boolean mailfaux = false;
                    while (!mailfaux) { // recuperer le mail 
                        mailfaux = true;
                        c = RechercheC(mail);
                        if (c == null) {
                            mailfaux = false;// verifie que le mail existe 
                            System.out.println("vs vs êtes trompé dans le mail");
                            System.out.println("entrez votre mail");
                            mail = sc.nextLine();
                        }
                    }

                    boolean testemdpbol = false;
                    while (!testemdpbol) {
                        System.out.println("entrez votre mdp");
                        String mdp = sc.nextLine();
                        testemdpbol = c.testMdp(mdp);// verifie que le mdp correponds au mail
                        if (!testemdpbol) {
                            System.out.println("vs vs êtes trompé dans le mdp");
                        }
                    }
                    utilisateurConnecte = c;
                    return 1;// createur 

                case 2: // investiseur 
                    mailfaux = false;
                    while (!mailfaux) {
                        mailfaux = true;
                        i = RechercheI(mail);
                        if (i == null) {
                            mailfaux = false;// verifie que le mail existe
                            System.out.println("vs vs êtes trompé dans le mail");
                            System.out.println("entrez votre mail");
                            mail = sc.nextLine();
                        }
                    }

                    testemdpbol = false;
                    while (!testemdpbol) {
                        System.out.println("entrez votre mdp");
                        String mdp = sc.nextLine();
                        testemdpbol = i.testMdp(mdp);// verifie que le mdp correponds au mail
                        if (!testemdpbol) {
                            System.out.println("vs vs êtes trompé dans le mdp");
                        }
                    }
                    utilisateurConnecte = i;
                    return 2;// investisseur 

                default:
                    System.out.println("vs vs êtes trompé dans le choix");  // traiter cas erreur lettre try and catch
                    stop = false;
            }
        }
        return 0;
    }

    public int Connexion(String mail, int type, String mdp) { // modifié pour la partie graphique 
        boolean stop = false;
        while (!stop) {
            stop = true;
            Createur c = null;
            Investisseur i = null;
            switch (type) {
                case 1:// createur 
                    boolean mailfaux = false;
                    c = RechercheC(mail);
                    if (c == null) {
                        mailfaux = false;
                        return 4; // transmettre que le mail est faux 
                    }

                    boolean testemdpbol = false;
                    testemdpbol = c.testMdp(mdp);
                    if (!testemdpbol) {
                        return 3; // pour dire a la fonction que le mdp est faux
                    }
                    utilisateurConnecte = c;
                    return 1;// createur 

                case 2:// investisseur 
                    i = RechercheI(mail);
                    if (i == null) {
                        mailfaux = false;
                        return 4; // transmettre que le mail est faux 
                    }
                    testemdpbol = false;
                    testemdpbol = i.testMdp(mdp);
                    if (!testemdpbol) {
                        return 3;// pour dire a la fonction que le mdp est faux
                    }
                    utilisateurConnecte = i;
                    return 2;// investisseur 

                default:// traiter cas erreur lettre try and catch
                    stop = false;
                    return 0;

            }
        }
        return 0;
    }

    public int Inscription(String mail) { // methode initial 
        String mdp = "";
        String mdpBis = "";
        LinkedList projetPropose = new LinkedList();
        LinkedList investissements = new LinkedList();
        Scanner sc = new Scanner(System.in);
        System.out.println(" INSCRIPTION : \n quel est votre nom ?");
        String nom = sc.nextLine();
        boolean ok = false;
        System.out.println(" quel est votre mdp ?");
        mdp = sc.nextLine();
        while (!ok) {
            System.out.println(" veillez confirmer votre mdp ?");
            mdpBis = sc.nextLine();
            if (mdp.equals(mdpBis)) {
                ok = true;
            }
        }
        boolean stop = false;
        while (!stop) {
            System.out.println(" créateur (1) investisseur (2) ");
            int type = sc.nextInt();
            stop = true;
            sc = new Scanner(System.in);
            switch (type) {
                case 1://cree un createur et l'ajoute a la iste 
                    Createur c = new Createur(nom, mail, mdp);
                    listC.add(c);
                    System.out.println(c);
                    utilisateurConnecte = c;
                    return 1;// createur 
                case 2:// cree un investisseur et l'ajoute a la liste 
                    Investisseur i = new Investisseur(nom, mail, mdp);
                    listI.add(i);
                    System.out.println(i);
                    utilisateurConnecte = i;
                    return 2;// investisseur 
                default:
                    System.out.println(" Vous vous etre trompé sur votre choix ");
                    stop = false;
            }
        }
        return 0; // si l'utilisateur c'est trompé 
    }

    public int Inscription(String mail, String nom, String mdp, int type) {// pour le graphique 
        LinkedList projetPropose = new LinkedList();
        LinkedList investissements = new LinkedList();
        boolean stop = false;
        while (!stop) {
            stop = true;
            switch (type) {
                case 1:// createur 
                    Createur c = new Createur(nom, mail, mdp);
                    listC.add(c);
                    System.out.println(c);
                    utilisateurConnecte = c;
                    return 1;
                case 2:// investisseur 
                    Investisseur i = new Investisseur(nom, mail, mdp);
                    listI.add(i);
                    System.out.println(i);
                    utilisateurConnecte = i;
                    return 2;
                default:
                    stop = false;
                    return 0;
            }
        }
        return 0; // si l'utilisateur c'est trompé 
    }

    public Createur RechercheC(String mail) {
        boolean trouve = false;
        Createur crea;
        crea = null;
        Iterator<Createur> it = listC.iterator();
        while (it.hasNext() && !trouve) {
            crea = it.next();
            if (crea.getmail().equals(mail)) {
                trouve = true;
            }
        }
        if (trouve == false) {
            crea = null;
        }
        return crea;
    }

    public Projet RechercheP(String id) { // on a separé la recherche par l'identifiant de la recherche par les autres critérezs car elle nous est utile pour appeler d'autre methode 
        boolean trouve = false;
        Projet proj;
        proj = null;
        Iterator<Projet> it = listProjets.iterator();
        while (it.hasNext() && !trouve) {
            proj = it.next();
            if (proj.getId().equals(id)) {
                trouve = true;
            }
        }
        if (trouve == false) {
            proj = null;
        }
        return proj;
    }

    public Projet RecherchePcreateur(String id) { // recherche parmis les projets du creatuer (il peut modifier que les siens) 
        boolean trouve = false;
        Projet proj;
        proj = null;
        Iterator<Projet> it = ((Createur) utilisateurConnecte).getListProjets().iterator();
        while (it.hasNext() && !trouve) {
            proj = it.next();
            if (proj.getId().equals(id)) {
                trouve = true;
            }
        }
        if (trouve == false) {
            proj = null;
        }
        return proj;
    }

    public Investisseur RechercheI(String mail) {
        boolean trouve = false;
        Investisseur invest;
        invest = null;
        Iterator<Investisseur> it = listI.iterator();
        while (it.hasNext() && !trouve) {
            invest = it.next();
            if (invest.getmail().equals(mail)) {
                trouve = true;
            }
        }
        if (trouve == false) {
            invest = null;
        }
        return invest;
    }

    public void RecherchePCritere() {// recherche par different critére les critéres initial 
        Projet proj;
        System.out.println(" Veillez choisir un critére de trie \n 1 : Idee \n 2 : Competences \n 3 : Secteur d'activité \n 4 : Contreparties \n 5 : Date de lancement \n 6 : Somme minimale \n 7 : Somme Recolte");
        Scanner sc = new Scanner(System.in);
        int trie = sc.nextInt();
        Iterator<Projet> it = listProjets.iterator();
        System.out.println(listProjets);
        switch (trie) {
            case 1:
                sc = new Scanner(System.in);
                boolean trouve = false;
                System.out.println(" Votre idee :");
                String idee = sc.nextLine();
                while (it.hasNext()) {
                    proj = it.next();
                    if (proj.getIdee().equals(idee)) {
                        System.out.println(proj);
                        trouve = true;
                        if (proj.getProjetAnnule() == true) { // on verifit a chaque fois si le projet est annulé ou si le projet est fermé 
                            System.out.println("Le projet que vous tentez de rechercher n'est plus d'actualité");
                        }
                        if (proj.getrecolteOuverte() == false) {
                            System.out.println("La recollte du projet dans lequel vous tentez d'investir n'est plus d'actualité");
                        }
                    }

                }
                if (trouve == false) {
                    System.out.println("Le projet que vous recherchez n'existe pas ");
                }
                break;

            case 2:
                sc = new Scanner(System.in);
                trouve = false;
                System.out.println(" Votre competence :");
                String competences = sc.nextLine();
                while (it.hasNext()) {
                    proj = it.next();
                    if (proj.getCompetences().equals(competences)) {
                        System.out.println(proj);
                        trouve = true;
                        if (proj.getProjetAnnule() == true) {
                            System.out.println("Le projet que vous tentez de rechercher n'est plus d'actualité");
                        }
                        if (proj.getrecolteOuverte() == false) {
                            System.out.println("La recollte du projet dans lequel vous tentez d'investir n'est plus d'actualité");
                        }
                    }
                }
                if (trouve == false) {
                    System.out.println("Le projet que vous recherchez n'existe pas ");
                }
                break;
            case 3:
                sc = new Scanner(System.in);
                trouve = false;
                System.out.println(" Votre secteurAct :");
                String secteurAct = sc.nextLine();
                while (it.hasNext()) {
                    proj = it.next();
                    if (proj.getSecteurAct().equals(secteurAct)) {
                        trouve = true;
                        System.out.println(proj);
                        if (proj.getProjetAnnule() == true) {
                            System.out.println("Le projet que vous tentez de rechercher n'est plus d'actualité");
                        }
                        if (proj.getrecolteOuverte() == false) {
                            System.out.println("La recollte du projet dans lequel vous tentez d'investir n'est plus d'actualité");
                        }
                    }
                }
                if (trouve == false) {
                    System.out.println("Le projet que vous recherchez n'existe pas ");
                }
                break;
            case 4:
                sc = new Scanner(System.in);
                trouve = false;
                System.out.println(" Votre contrepartie :");
                String contreparties = sc.nextLine();
                while (it.hasNext()) {
                    proj = it.next();
                    if (proj.getContreparties().equals(contreparties)) {
                        System.out.println(proj);
                        trouve = true;
                        if (proj.getProjetAnnule() == true) {
                            System.out.println("Le projet que vous tentez de rechercher n'est plus d'actualité");
                        }
                        if (proj.getrecolteOuverte() == false) {
                            System.out.println("La recollte du projet dans lequel vous tentez d'investir n'est plus d'actualité");
                        }
                    }
                }
                if (trouve == false) {
                    System.out.println("Le projet que vous recherchez n'existe pas ");
                }
                break;

            case 5:
                sc = new Scanner(System.in);
                trouve = false;
                System.out.println(" Votre DateLancement (forme : dd-MM-yyyy:");
                String DateLancement = sc.nextLine();
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                LocalDate newDateLancement = LocalDate.parse(DateLancement, formatter);
                while (it.hasNext()) {
                    proj = it.next();
                    System.out.println(" si la date est la meme ");
                    if (proj.getDateLancement().equals(newDateLancement)) {
                        System.out.println(proj);
                        trouve = true;
                        if (proj.getProjetAnnule() == true) {
                            System.out.println("Le projet que vous tentez de rechercher n'est plus d'actualité");
                        }
                        if (proj.getrecolteOuverte() == false) {
                            System.out.println("La recollte du projet dans lequel vous tentez d'investir n'est plus d'actualité");
                        }
                    }
                }
                if (trouve == false) {
                    System.out.println("Le projet que vous recherchez n'existe pas ");
                }
                break;
            case 6:
                trouve = false;
                sc = new Scanner(System.in);
                System.out.println(" Votre sommeMin");
                int sommeMin = sc.nextInt();
                while (it.hasNext()) {
                    proj = it.next();

                    if (proj.getSommeMin() >= sommeMin) {
                        System.out.println(" si sa somme min inferieure ou égale a toutes celles des projets");
                        System.out.println(proj);
                        trouve = true;
                        if (proj.getProjetAnnule() == true) {
                            System.out.println("Le projet que vous tentez de rechercher n'est plus d'actualité");
                        }
                        if (proj.getrecolteOuverte() == false) {
                            System.out.println("La recollte du projet dans lequel vous tentez d'investir n'est plus d'actualité");
                        }
                    }
                }
                if (trouve == false) {
                    System.out.println("Le projet que vous recherchez n'existe pas ");
                }
                break;
            case 7:
                sc = new Scanner(System.in);
                trouve = false;
                System.out.println(" Votre sommeRecolte");
                int sommeRecolte = sc.nextInt();
                while (it.hasNext()) {
                    proj = it.next();

                    if (proj.getSommeRecolte() == sommeRecolte) {
                        System.out.println(" si sa somme reccolte égale à celles des projets");
                        System.out.println(proj);
                        trouve = true;
                        if (proj.getProjetAnnule() == true) {
                            System.out.println("Le projet que vous tentez de rechercher n'est plus d'actualité");
                        }
                        if (proj.getrecolteOuverte() == false) {
                            System.out.println("La recollte du projet dans lequel vous tentez d'investir n'est plus d'actualité");
                        }
                    }
                }
                if (trouve == false) {
                    System.out.println("Le projet que vous recherchez n'existe pas ");
                }
                break;
            default:
                System.out.println(" Vous vous etes trompés, le projet que vous tentez de rechercher n'éxiste pas !");
        }
    }

    public void VoirInfosCreateur(Createur c) {
        System.out.println(" *********************************************");
        System.out.println(c);
        System.out.println(" *********************************************");

    }

    public void VoirInfosInvestisseur(Investisseur i) {
        System.out.println(" *********************************************");
        System.out.println(i);
        System.out.println(" *********************************************");

    }

    public void VoirInfosProjet(Projet p) {

        System.out.println(" *********************************************");
        if (p == null) {
            System.out.println("vous n'avez pas de projet avec cet identifiant ");
        } else {
            System.out.println(p);
        }
        System.out.println(" *********************************************");

    }

    public void VoirProjetCreateur() {
        System.out.println(" *********************************************");
        System.out.println(((Createur) utilisateurConnecte).getListProjets());
        System.out.println(" *********************************************");
    }

    public void Sauvegarde() { // generale 

        String fichierp = nomDossier + "FichierProjet";
        String fichierc = nomDossier + "FichierCreateur";
        String fichieri = nomDossier + "FichierInvestisseur";

        try {
            FileWriter fich = new FileWriter(fichierp);
            fich.write("Fichier Projet \n");
            fich.close();
            System.out.println("je suis lo");
        } catch (IOException ex) { // recupére l'erreur 
            System.out.println("erreur dans la sauvegarde ");
        }
        Iterator<Projet> it = listProjets.iterator();
        while (it.hasNext()) {
            Projet projet = it.next();
            projet.sauvegarde(fichierp);
        }
        try {
            FileWriter fich = new FileWriter(fichierc);
            fich.write("Fichier Createur");
            fich.close();
        } catch (IOException ex) { // recupére l'erreur
            System.out.println("erreur dans la sauvegarde ");
        }
        Iterator<Createur> itc = listC.iterator();
        while (itc.hasNext()) {
            Createur crea = itc.next();
            crea.sauvegarde(fichierc);
        }
        try {
            FileWriter fich = new FileWriter(fichieri);
            fich.write("Fichier Investisseur");
            fich.close();
        } catch (IOException ex) { // recupére l'erreur
            System.out.println("erreur dans la sauvgarde ");
        }
        Iterator<Investisseur> iti = listI.iterator();
        while (iti.hasNext()) {
            Investisseur invest = iti.next();
            invest.sauvegarde(fichieri);
        }
          
    }

    public void chargement() {
        
        try {
            nbrProjet = 0;
            nbrProjet = this.chargerP(); // on doit charger les projet en premier car on a besoin de leur id dans createur et investisseur 
            System.out.println(nbrProjet);
        } catch (IOException pb) { // recupére l'erreur
            System.out.println("Probleme de chargement ");
        }
        try {
            this.chargerC();
        } catch (IOException pb) { // recupére l'erreur
            System.out.println("Probleme de chargement ");
        }
        try {
            this.chargerI();
        } catch (IOException pb) { // recupére l'erreur
            System.out.println("Probleme de chargement ");
        }
        
         System.out.println(listC);
         System.out.println(listI); 
         System.out.println(listProjets);
    }

    public void chargerI() throws IOException { // propage l'exception 
        FileReader fich = new FileReader(nomDossier + "FichierInvestisseur");
        BufferedReader br = new BufferedReader(fich);
        String ligne = br.readLine();
        ligne = br.readLine();
        try {
            while (ligne != null) {
                String nom = ligne;
                ligne = br.readLine();
                String mail = ligne;
                ligne = br.readLine();
                String mdp = ligne;
                Investisseur i = new Investisseur(nom, mail, mdp);
                listI.add(i);
                ligne = br.readLine();
                ligne = br.readLine();
                while (ligne.length() != 0) {
                    int sommeInvest = Integer.parseInt(ligne);
                    ligne = br.readLine();
                    String id = ligne;
                    Projet element = this.RechercheP(id);
                    Contribution contri = new Contribution(element, sommeInvest);
                    i.soutienP(element, contri);
                    ligne = br.readLine();
                }
                ligne = br.readLine();
            }
        } catch (NullPointerException ex) {
            System.out.println("fin de fichier");
        }
        fich.close();
    }

    public int chargerP() throws IOException { // propage l'exception 
        nbrProjet = 0;
        FileReader fich = new FileReader(nomDossier + "FichierProjet");
        BufferedReader br = new BufferedReader(fich);
        String ligne = br.readLine();
        ligne = br.readLine();

        try {
            while (ligne != null) {
                nbrProjet++;
                String idee = ligne;
                ligne = br.readLine();
                String competence = ligne;   //attention quand plusieurs compétences !!!!!  --> pouvoir les séparer
                ligne = br.readLine();
                String secteurAct = ligne;
                ligne = br.readLine();
                String contreparties = ligne;
                ligne = br.readLine();
                String id = ligne;
                ligne = br.readLine();
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                LocalDate dateLancement = LocalDate.parse(ligne, formatter);;
                ligne = br.readLine();
                int montantFond = Integer.parseInt(ligne);
                ligne = br.readLine();
                int sommeMin = Integer.parseInt(ligne);
                ligne = br.readLine();
                int sommeRecolte = Integer.parseInt(ligne);// creation du projet 
                Projet p = new Projet(idee, competence, secteurAct, contreparties, id, dateLancement, montantFond, sommeMin);
                p.augmenterRecolte(sommeRecolte);// on utilise les fonction pour modifier la somme etc... 
                listProjets.add(p);
                ligne = br.readLine();
                boolean recolteOuverte = Boolean.parseBoolean(ligne); // recuperer recolte ouverte ou fermmé 
                ligne = br.readLine();
                if (recolteOuverte == false) {
                    p.fermeRecolte();
                }
                boolean projetAnnule = Boolean.parseBoolean(ligne);// recuperer projet d'actualité ou annuler 
                if (projetAnnule == true) {
                    p.projetAnnule();
                }
                ligne = br.readLine();
                while (ligne.length() != 0) {
                    String mailI = ligne;
                    ligne = br.readLine();
                    String texteRecom = ligne;
                    Recommandation recom = new Recommandation(texteRecom, mailI);
                    p.donnerRecom(recom);
                    ligne = br.readLine();
                }
                ligne = br.readLine();
                // System.out.println(p); 

            }
        } catch (NullPointerException ex) {
            System.out.println("fin de fichier");
        }
        fich.close();
        return nbrProjet;
    }

    public void chargerC() throws IOException { // propage l'exception 
        FileReader fich = new FileReader(nomDossier + "FichierCreateur");
        BufferedReader br = new BufferedReader(fich);
        String ligne = br.readLine();
        ligne = br.readLine();
        try {
            while (ligne != null) {
                String nom = ligne;
                ligne = br.readLine();
                String mail = ligne;
                ligne = br.readLine();
                String mdp = ligne;
                Createur c = new Createur(nom, mail, mdp);
                listC.add(c);
                ligne = br.readLine();
                ligne = br.readLine();
                while (ligne.length() != 0) {
                    String id = ligne;
                    Projet element = this.RechercheP(id);
                    c.newProjet(element);
                    ligne = br.readLine();
                }
                ligne = br.readLine();
            }
        } catch (NullPointerException ex) {
            System.out.println("fin de fichier");
        }
        fich.close();
    }

    public void proposeProjet() { // methode initial 
        int sommeMin = 0;
        int montantFond = 0;
        Scanner sc = new Scanner(System.in);
        System.out.println(" Creation d'un nouveau projet ");
        nbrProjet++;
        String id = 'A' + String.valueOf(nbrProjet);
        System.out.println(" Votre projet a pour identifiant : " + id);
        System.out.println(" Veillez entrez la description de votre projet");
        String idée = sc.nextLine();
        System.out.println(" Veillez entrer vos competance ( sans accent, sous la fomre de : implique ; serieux ; etc...)");// exiger une forme 
        String competance = sc.nextLine(); // trouver un moyen pour refuser si on ne respecte pas la forme type
        System.out.println(" Veillez indiquer le secteur d'activité "); // afficher une liste 
        String secteurActivite = sc.nextLine();
        System.out.println(" Veillez indiquer les contreparties ( sous la fomre : argent ; bien ; etc...)");
        String contreparties = sc.nextLine();
        System.out.println(" Veillez entre la date de lancement de votre projet (sous la forme JJ-MM-YYYY)");
        String dateLancement = sc.nextLine();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDate newDateLancement = LocalDate.parse(dateLancement, formatter);
        boolean entier = false;
        while (!entier) {
            try {
                entier = true;
                System.out.println(" Veillez indiquer le montant de fond necessaire au lancement du projet");
                montantFond = sc.nextInt();
            } catch (InputMismatchException ex) {
                System.out.println(" Veuillez mettre un entier");
                sc = new Scanner(System.in);
                entier = false;
            }
        }
        entier = false;
        while (!entier) {
            try {
                entier = true;
                System.out.println(" Veillez indiquer la somme minimal pour participer a ce projet");
                sommeMin = sc.nextInt();
            } catch (InputMismatchException ex) {
                System.out.println(" Veuillez mettre un entier");
                sc = new Scanner(System.in);
                entier = false;
            }
        }
        Projet p = ((Createur) utilisateurConnecte).newProjet(idée, competance, secteurActivite, contreparties, id, newDateLancement, montantFond, sommeMin);
        listProjets.add(p);
        // System.out.println(p);
    }

    // methode pour la partie graphique 
    public Projet proposeProjet(String idee, String competences, String contreparties, String secteuract, LocalDate datelancement, int montantfond, int sommemin) {
        nbrProjet++;
        String id = 'A' + String.valueOf(nbrProjet);
        Projet p = ((Createur) utilisateurConnecte).newProjet(idee, competences, secteuract, contreparties, id, datelancement, montantfond, sommemin);
        listProjets.add(p);
        return p;
    }

    public void cloreCollecteAuto() { // sans demander lavis du createur, est appellé automatiquement quand la somme voulu est atteinte  
        ((Createur) utilisateurConnecte).cloreCollectauto();
    }

    public void cloreCollect(Projet p) {// methode initial 
        if (p == null) {
            System.out.println("vous n'avez pas de projet avec cet identifiant ");
        } else {
            ((Createur) utilisateurConnecte).cloreCollect(p);
        }
    }

    public void cloreCollect1(Projet p) {// methode graphique 
        ((Createur) utilisateurConnecte).cloreCollect(p);
    }

    public void projetAnnule(Projet p) {// methode inital 
        if (p == null) {
            System.out.println("vous n'avez pas de projet avec cet identifiant ");
        } else {
            ((Createur) utilisateurConnecte).projetAnnule(p);
        }
    }

    public void projetAnnule1(Projet p) {// methode graphique 
        ((Createur) utilisateurConnecte).projetAnnule(p);
    }

    public void soutientProjet(Projet p, int sommeInvestit) {  // crer une contribution methode initial 
        p.addMontant(sommeInvestit);
        if (p.getProjetAnnule() == true) {
            System.out.println("Le projet dans lequel vous tentez d'investir n'est plus d'actualité");
        }
        if (p.getrecolteOuverte() == false) {
            System.out.println("La recollte du projet dans lequel vous tentez d'investir n'est plus d'actualité");
        }
        if (sommeInvestit < p.getSommeMin()) {
            System.out.println("La somme que vous avez rentré est inferieur a la somme minimum de se projet, votre investissement a échoué ");
        }
        if (sommeInvestit >= p.getSommeMin()) {
            Contribution contri = new Contribution(p, sommeInvestit);

            ((Investisseur) utilisateurConnecte).soutienP(p, contri);
            p.soutienProjet(contri);
        }
    }

    public void soutientProjet1(Projet proj, int sommeInvestit) {// crer une contribution methode graphique 
        if (sommeInvestit >= proj.getSommeMin()) {
            Contribution contri = new Contribution(proj, sommeInvestit);
            ((Investisseur) utilisateurConnecte).soutienP(proj, contri);
            proj.soutienProjet(contri);
        }
    }

    public void prolongeDate(Projet p) {// methode initial 
        if (p == null) {
            System.out.println("vous n'avez pas de projet avec cet identifiant ");
        } else {
            ((Createur) utilisateurConnecte).prolongationDate(p);
        }
    }

    public void prolongeDate(Projet p, String date) {// methode graphique 
        if (p == null) {
        } else {
            ((Createur) utilisateurConnecte).prolongationDate(p, date);
        }
    }

    public void donnerRecommandation(Projet p, String textRecom) {
        Recommandation recom = new Recommandation(textRecom, (utilisateurConnecte.getmail()));
        p.donnerRecom(recom);
    }

    public void BilanIvestissement() { // methode initiale 
        ((Investisseur) utilisateurConnecte).BilanInvest();
    }

    public LinkedList<Contribution> BilanIvestissement1() {// methode graphique 
        return ((Investisseur) utilisateurConnecte).getInvestissements();

    }

    public int BilanIvestissement2() { // methode pour avoir la somme des investissement
        return ((Investisseur) utilisateurConnecte).BilanInvest2();
    }

}
