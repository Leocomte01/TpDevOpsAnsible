/*
finacement participatif 
Marion Chineaud & Vincent Flamain 
06/02/21
 */
package sitedefinancementparticipatif;

import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author vincent
 */
public class Recommandation {

    private String texte;
    private String mailInvestisseur;

    public Recommandation(String texte, String mailInvestisseur) {
        this.texte = texte;
        this.mailInvestisseur= mailInvestisseur;
    }

    @Override
    public String toString() {
        return "Recommandation{" + "texte=" + texte + ", investisseur=" + mailInvestisseur + '}';
    }

   /* public void sauvegarde(String nomFichier) {
        try {
            FileWriter fich = new FileWriter(nomFichier, true);
            fich.write(mailInvestisseur + System.lineSeparator());
            fich.write(texte + System.lineSeparator());
            fich.close();
        } catch (IOException ex) {
            System.out.println("erreur dans la sauvgarde ");

        }
    }*/

    public void sauvegarde(FileWriter fich) { 
        try {
            fich.write(mailInvestisseur + System.lineSeparator());
            fich.write(texte + System.lineSeparator());

        } catch (IOException ex) {
            System.out.println("erreur dans la sauvgarde ");

        }
    }
}
