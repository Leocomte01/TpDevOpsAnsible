/*
financement participatif 
Marion Chineaud & Vincent Flamain 
06/02/21
 */
package sitedefinancementparticipatif;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Iterator;
import java.util.LinkedList;

/**
 *
 * @author vincent
 */
public class Projet {

    private String idee;
    private String competences;
    private String secteurAct;
    private String contreparties;
    private String id;
    private LocalDate dateLancement;
    private int montantFond;
    private int sommeMin;
    private int sommeRecolte;
    private LinkedList<Contribution> listContributions;
    private LinkedList<Recommandation> listRecommandations;
    private boolean recolteOuverte;
    private boolean projetAnnule;
    private String nomDossier = "src\\Sauvegardes\\";

    public Projet(String idee, String competences, String secteurAct, String contreparties, String id, LocalDate dateLancement, int montantFond, int sommeMin) {
        this.idee = idee;
        this.competences = competences;
        this.secteurAct = secteurAct;
        this.contreparties = contreparties;
        this.id = id;
        this.dateLancement = dateLancement;
        this.montantFond = montantFond;
        this.sommeMin = sommeMin;
        this.sommeRecolte = 0;
        this.recolteOuverte = true; // initialisé a vrais car un nouveau projet a toujors la collecte ouverte 
        this.listContributions = new LinkedList<Contribution>(); // initialisé a vide car son complété apres la creation par les investiseur 
        this.listRecommandations = new LinkedList< Recommandation>();// initialisé a vide car son complété apres la creation par les investiseur
        this.projetAnnule = false; // meme idée que pour la fermeture de collecte 
    }

    public boolean getrecolteOuverte() {
        return recolteOuverte;
    }

    public int getMontantFond() {
        return montantFond;
    }

    public String getIdee() {
        return idee;
    }

    public String getCompetences() {
        return competences;
    }

    public String getSecteurAct() {
        return secteurAct;
    }

    public String getContreparties() {
        return contreparties;
    }

    public int getSommeMin() {
        return sommeMin;
    }

    public int getSommeRecolte() {
        return sommeRecolte;
    }

    public LocalDate getDateLancement() {
        return dateLancement;
    }

    public String getId() {
        return id;
    }

    public boolean getProjetAnnule() {
        return projetAnnule;
    }

    public void addMontant(int montantAjouté) {
        montantFond += montantAjouté;
    }

    @Override
    public String toString() {
        return "Projet{  " + "idee=" + idee + "\n competences=" + competences + "\n secteur d'activité="
                            + secteurAct + "\n contreparties=" + contreparties + "\n id=" + id + "\n date de lancement="
                            + dateLancement + "\n montant fonds=" + montantFond + "\n somme minimale=" + sommeMin + "\n somme recoltée="
                            + sommeRecolte + "\n la recolte est " + recolteOuverte + "\n le projet est annulé " + projetAnnule + "\n liste des contributions=" + listContributions + "\n  listRecommandations="
                            + listRecommandations + '}' + "\n";
    }

    public void fermeRecolte() {
        recolteOuverte = false;
    }

    public void projetAnnule() {
        projetAnnule = true;
    }

    public void prolongDate(LocalDate d) {
        dateLancement = d;
        System.out.println("Voici la nouvelle date de lancement " + d);
    }

    public void soutienProjet(Contribution contri) {
        listContributions.add(contri);
    }

    public void augmenterRecolte(Contribution contri) {
        sommeRecolte += contri.getSommeInvestie();
    }

    public void augmenterRecolte(int somme) {
        sommeRecolte += somme;
    }

    public void donnerRecom(Recommandation recom) {
        listRecommandations.add(recom);
    }

    public void sauvegarde(String nomFichier) { // sauvgarde le projet dans le fichier projet 
        try {
            FileWriter fich = new FileWriter(nomFichier, true);
            fich.write(idee + System.lineSeparator());
            fich.write(competences + System.lineSeparator());
            fich.write(secteurAct + System.lineSeparator());
            fich.write(contreparties + System.lineSeparator());
            fich.write(id + System.lineSeparator());
            fich.write(dateLancement + System.lineSeparator());
            fich.write(montantFond + System.lineSeparator());
            fich.write(sommeMin + System.lineSeparator());
            fich.write(sommeRecolte + System.lineSeparator());
            fich.write(recolteOuverte + System.lineSeparator());
            fich.write(projetAnnule + System.lineSeparator());
            Iterator<Recommandation> it = listRecommandations.iterator();
            while (it.hasNext()) { // pb creation contribution et recomandation 
                Recommandation recommandation = it.next();
                recommandation.sauvegarde(fich);
            }
            fich.write(System.lineSeparator());
            fich.close();
            /* 
            pas forcement necesaire d'enregistrer la liste des contribution dans projet vue que l'on l'enregistre dans investiseur 
            Iterator<Contribution> itt = listContributions.iterator();
            while (itt.hasNext()) { // a tester 
                Contribution contribution = itt.next();
                contribution.sauvegarde(nomFichier);
            }*/
        } catch (IOException ex) {
            System.out.println("erreur dans la sauvgarde ");
        }
    }

    public void sauvegarder(String nomFichier) { // saugarde juste l'id dans le fichier createur pour savoir quel createur a creé quel fichier 
        try {
            FileWriter fich = new FileWriter(nomFichier, true);
            fich.write(id + System.lineSeparator());
            fich.close();
        } catch (IOException ex) {
            System.out.println("erreur dans la sauvgarde ");
        }
    }

}
