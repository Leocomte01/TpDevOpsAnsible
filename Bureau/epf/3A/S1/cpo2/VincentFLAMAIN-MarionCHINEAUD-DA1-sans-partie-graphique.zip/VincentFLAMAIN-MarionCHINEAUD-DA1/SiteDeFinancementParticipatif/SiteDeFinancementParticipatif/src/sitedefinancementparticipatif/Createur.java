/*
financement participatif 
Marion Chineaud & Vincent Flamain 
06/02/21
 */
package sitedefinancementparticipatif;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;
import javax.swing.text.DateFormatter;

/**
 *
 * @author vincent
 */
public class Createur extends Utilisateur {

    private LinkedList projetProposeC;

    public Createur(String nom, String mail, String mdp) {
        super(nom, mail, mdp);
        projetProposeC = new LinkedList<>();
    }

    @Override
    public String toString() {
        return " Createur : " + "\n nom=" + super.nom + "\n mail=" + super.mail + " \n mdp=" + super.mdp + " \n  projet proposé =" + projetProposeC;
    }

    public Projet newProjet(String idee, String competences, String secteurAct, String contreparties, String id, LocalDate dateLancement, int montantFond, int sommeMin) {
        Projet p = new Projet(idee, competences, secteurAct, contreparties, id, dateLancement, montantFond, sommeMin);
        projetProposeC.add(p); // on ajoute le projet a la liste du createur 
        return p;
    }
    
    
    
    public void newProjet(Projet p){ // pour ajouter le projet a la liste 
        projetProposeC.add(p);
    }

    public void voirInfosP(Projet p) {
        System.out.println(p);
    }

    public LinkedList getListProjets() {
        return projetProposeC;
    }

    public void cloreCollectauto() { // pour clore la collecte losque la somme limite est depassé 
        boolean stop = false;
        Iterator<Projet> it = projetProposeC.iterator();
        while (it.hasNext()) {
            Projet p = it.next();
            if (p.getMontantFond() <= p.getSommeRecolte() ) {
                stop = true;
                System.out.println(" La sommme est depassée pour votre projet d'identifiant " + p.getId() + " = cloture de la cagnote");
                p.fermeRecolte();
            }
        }
    }

    public void cloreCollect(Projet p) { // si un createur veut fermer la collecte 
        p.fermeRecolte();
    }
    
    public void projetAnnule(Projet p){ // si le createur veut annuller son projet 
        p.projetAnnule();
    }
   

    public void prolongationDate(Projet p) { // modification de la date de lancement 
        System.out.println(" Voici la date de lancement du projet actuelle" + p.getDateLancement());
        Scanner sc = new Scanner(System.in);
        System.out.println(" Entrez la nouvelle date de la forme : DD-MM-YYYY");
        String newDate = sc.nextLine();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDate newDateLocal = LocalDate.parse(newDate, formatter);
        p.prolongDate(newDateLocal);
    }
        // meme methode adapté au forma graphique
        public void prolongationDate(Projet p, String date ) { // modification de la date de lancement 
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDate newDateLocal = LocalDate.parse(date, formatter);
        p.prolongDate(newDateLocal);
    }


    public void sauvegarde(String nomFichier) {  
        // String nomFichier = "src\\Sauvegardes\\FichierCreateur";
        super.sauvegarde(nomFichier);
        Iterator<Projet> it = projetProposeC.iterator();
        while (it.hasNext()) {
            Projet projet = it.next();
            projet.sauvegarder(nomFichier);
        }

    }


}
