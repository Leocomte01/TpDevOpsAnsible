/*
financement participatif 
Marion Chineaud & Vincent Flamain 
06/02/21
 */
package sitedefinancementparticipatif;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedList;

/**
 *
 * @author mario
 */
public class Investisseur extends Utilisateur {

    private LinkedList <Contribution> investissements;
  

    public Investisseur( String nom, String mail, String mdp) {
        super(nom, mail, mdp);
        this.investissements = new LinkedList <Contribution > () ;

    }

    @Override
    public String toString() {
        return " Investisseur : " + "\n nom=" + super.nom + "\n mail=" + super.mail + " \n mdp=" + super.mdp + " \n investissements=" + investissements;
    }

    public LinkedList<Contribution> getInvestissements() { // retourne la liste des investissements 
        return investissements;// utiliser por le bilan sur investissement dans la partie graphique 
    }

    public void soutienP(Projet p , Contribution c) { 
        investissements.add(c);
        p.augmenterRecolte(c);
        //p.soutienProjet(c); // provoque un erreur de le lancement du code 
    }

    public void BilanInvest() { // affiche la liste des investissement 
        Iterator<Contribution> it = investissements.iterator();
                while (it.hasNext()) {
                    Contribution contri = it.next();
                    System.out.println(contri);
                }
    }
    
        public int BilanInvest2() { // affiche la liste des investissement 
            int tot= 0; 
        Iterator<Contribution> it = investissements.iterator();
                while (it.hasNext()) {
                    Contribution contri = it.next();
                    tot+= contri.getSommeInvestie(); 
                    //System.out.println(contri);
                }
                return tot; 
    }
    

    public void sauvegarde(String nomFichier) {
        // String nomFichier = "src\\Sauvegardes\\FichierInvestisseur";
        super.sauvegarde(nomFichier);
        Iterator<Contribution> itc = investissements.iterator();
        while (itc.hasNext()) {
           Contribution contri = itc.next();
            contri.sauvegarde(nomFichier);
        }
    }
    


}
